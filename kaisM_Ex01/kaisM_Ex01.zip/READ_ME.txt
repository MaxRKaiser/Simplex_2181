Source: https://www.bensound.com/royalty-free-music/track/creative-minds

Path:   ..\\_Binary\\Data\\Audio\\mySound.wav

Issues: Arcball integration is only half there, the pencil will rotate with the cube, but the matrix doesn't mesh properly with the rotation to set the pencil perpendicular to the cube, resulting in a wonky overall orientation.